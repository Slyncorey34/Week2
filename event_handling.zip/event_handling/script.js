$(document).ready(function() {

  var $listItems = $('li');
  //var $newItemForm = $('#newItemForm');

  $listItems.on('click', function(){
    $(this).addClass('complete');
  })

 // $newItemForm.on('submit', function(e) {       // When a new item is submitted
 //   e.preventDefault();                         // Prevent form being submitted
 //   var text = $('input').val();           // Get value of text input
 //   $('ul').append('<li>' + text + '</li>');      // Add item to end of the list
//  $('input').val('');                    // Empty the text input
                        
 // });

});